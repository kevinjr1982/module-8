package com.gamingroom.gameauth.auth;

public class List<T> {

}
