package com.gamingroom;


/**
 * A simple class to hold information about a game
 * 
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a game is
 * created.
 * </p>
 * 
 * @author coce@snhu.edu
 *
 */
public class Game {
	long id;
	String name;
	
	private Game() {
}
	public Game(long id, String name) {
		this();
		this.id = id;
		this.name = name;
	}
	
	public long getid() {
		return id;
	}


	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		
		return "Game [id=" + id + ", name=" + name + "]";
	}

}
