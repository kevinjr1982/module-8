package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 */
public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	/*
	 * Holds the next game identifier
	 */
	private static long nextGameId = 1;
	@SuppressWarnings("unused")
	private static GameService instance = new
			GameService();
	
	private void GameService() {
	}
	
	public static Game addGame(String name(){
		return instance;
	}

	// FIXME: Add missing pieces to turn this class a singleton 


	public Game addGame(String name) {

		// a local game instance
		Game game = null;

		//if game with name exists return name
		
	    for(Game currentGame:games) {
	    	if(currentGame.getName().equals(name)) {
	    		
	    		return currentGame;
	    	}
	    }
		if (game == null) {
			game = new Game(nextGameId++, name);
			games.add(game);
		}

		// return the new/existing game instance to the caller
		return game;
	}

	private static GameService newGameService() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 */
	Game getGame(int index) {
		return games.get(index);
	}
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		// a local game instance
		Game game = null;

		// a local game instance
		
		// if game exists with idI'd return Game instance

		for(Game currentGame:games) {
			if(currentGame.getid() == id) {
		}
		}
		return game;
	}

	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;

		// returnsreturns game with specified name
		
		for(Game currentGame:games) {
			if(currentGame.getName().equals(name)) {
				game = currentGame;
			}
		}

		return game;
	}

	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}

	public static GameService getInstance() {
		// TODO Auto-generated method stub
		return null;
	}

	public static void setInstance(GameService instance) {
	}
}
